<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
@include('partials.direcciones')
</head>
<body>
   

        @yield('content')
</body>
</html>
