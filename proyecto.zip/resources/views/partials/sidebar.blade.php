<div class="full-width navLateral-bg btn-menu"></div>
<div class="full-width navLateral-body">
    <div class="full-width navLateral-body-logo text-center tittles">
        <i class="zmdi zmdi-close btn-menu"></i> Inventory
    </div>
    <figure class="full-width navLateral-body-tittle-