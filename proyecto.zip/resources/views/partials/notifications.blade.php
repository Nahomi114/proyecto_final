<div class="full-width container-notifications-bg btn-Notification"></div>
<section class="NotificationArea">
    <div class="full-width text-center NotificationArea-title tittles">Notificaciones <i class="zmdi zmdi-close btn-Notification"></i></div>
    <!-- Notification items -->
</section>